import { Component, OnInit, Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Observable, timer } from 'rxjs';
import { Question } from "./model/question";

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})

@Injectable()
export class TestComponent implements OnInit {
  time;
  timeLeft: number = 1500;
  subscribeTimer: number = 1500;
  oberserableTimer() {
    const source = timer(1000, 1000);
    source.subscribe(val => {     
        this.subscribeTimer = this.timeLeft - val;
   
      this.time = this.transform(this.subscribeTimer);
    });  
    stop;  
  }

  transform(value: number): string {
    const minutes: number = Math.floor(value / 60);
    return minutes.toString().padStart(2, '0') + ':' + 
        (value - minutes * 60).toString().padStart(2, '0');
 }

  start = true;
  private categorie: String = 'A';
  public numberQuestion: number = 0;
  resultTest: String;
  yourAnswer: String = "test";
  buttonYes: String = '#e7e7e7';
  buttonNo: String = '#e7e7e7';
  buttonAnswerA: String = '#e7e7e7';
  buttonAnswerB: String = '#e7e7e7';
  buttonAnswerC: String = '#e7e7e7';

  _questions: Array<Categorie> = new Array(
    new Categorie('Test kategoria A', 'A'),
    new Categorie('Test kategoria B', 'B'),
    new Categorie('Test kategoria C', 'C')
  )

  endtest: boolean = false;
  userAnswer: Array<saveAnswer> = new Array();
  map: Map<number, String> = new Map();
  questions: Array<Question>;
  _questionsInTest;
  question: Question;

  constructor(private route: ActivatedRoute, private http: HttpClient) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this._questionsInTest = new Array();
      this.getQuestion(params.get("id"));
    })

    this.getTestQuestions().subscribe(data => {
      this.questions = data;
    });

  }

  getTestQuestions(): Observable<any> {
    return this.http.get('//localhost:9001/test/' + this.categorie);
  }

  getQuestion(categorie: String) {
    this._questions.forEach(_question => {
      _question.categorie == categorie ? this._questionsInTest.push(_question) : null
    });
  }

  getQuestions() {
    try { return this.questions[this.numberQuestion]; } catch (error) { }
  }

  getAnswer() {
    return this.questions[this.numberQuestion].answerPL;
  }

  getNumberQuestion() {
    return this.numberQuestion + 1;
  }

  endTest() {
    this.endtest = true;
    this.resultTest = this.isComplited();
    this.answerGood();
    this.yourAnswer = this.map.get(this.numberQuestion);
  }

  isComplited() {
    let pkt;
    let result;
    if (this.endtest) {
      let i = 0;
      this.questions.forEach(question => {
        question.correctAnswer === this.map.get(i++) ? pkt += Number(question.pkt) : null;
      });
    }
    if (pkt < 64) {
      result = "Zdałeś"
    } else {
      result = "Nie zdałeś"
    }
    return result;
  }

  allButtonSetColor() {
    this.buttonYes = '#e7e7e7';
    this.buttonNo = '#e7e7e7';
    this.buttonAnswerA = '#e7e7e7';
    this.buttonAnswerB = '#e7e7e7';
    this.buttonAnswerC = '#e7e7e7';
  }

  nextQuestion() {
    if (this.numberQuestion < 29) {
      this.oberserableTimer();
      this.numberQuestion++;
      if (!this.endtest) {
        this.allButtonSetColor();
        if (this.map.get(this.numberQuestion) !== null)
          this.answer(this.map.get(this.numberQuestion))
      } else {
        this.answerGood();
        this.yourAnswer = this.map.get(this.numberQuestion);
      }
    }
  }

  prevQuestion() {
    if (this.numberQuestion > 0) {
      this.numberQuestion -= 1;
      if (!this.endtest) {
        this.allButtonSetColor();
        if (this.map.get(this.numberQuestion) !== null)
          this.answer(this.map.get(this.numberQuestion))
      } else {
        this.answerGood();
        this.yourAnswer = this.map.get(this.numberQuestion);
      }
    }
  }

  checkIfAnswerIstEmpty() {
    try {
      if (this.getQuestions().answerPL.answer1 == '')
        return false;
      else
        return true;
    } catch (error) { }

  }

  answerGood() {
    switch (this.questions[this.numberQuestion].correctAnswer) {
      case 'T':
        this.buttonYes = 'green';
        this.buttonNo = 'red';
        break;
      case 'N':
        this.buttonYes = 'red';
        this.buttonNo = 'green';
        break;
      case 'A':
        this.buttonAnswerA = 'green';
        this.buttonAnswerB = 'red';
        this.buttonAnswerC = 'red';
        break;
      case 'B':
        this.buttonAnswerA = 'red';
        this.buttonAnswerB = 'green';
        this.buttonAnswerC = 'red';
        break;
      case 'C':
        this.buttonAnswerA = 'red';
        this.buttonAnswerB = 'red';
        this.buttonAnswerC = 'green';
        break;
      default:
        this.allButtonSetColor();
        break;
    }
  }

  answer(answer: String) {
    if (!this.endtest) {
      switch (answer) {
        case 'T':
          this.map.set(this.numberQuestion, 'T');
          this.buttonNo = '#e7e7e7';
          this.buttonYes = 'green';
          break;
        case 'N':
          this.map.set(this.numberQuestion, 'N');
          this.buttonNo = 'green';
          this.buttonYes = '#e7e7e7';
          break;
        case 'A':
          this.map.set(this.numberQuestion, 'A');
          this.buttonAnswerA = 'green';
          this.buttonAnswerB = '#e7e7e7';
          this.buttonAnswerC = '#e7e7e7';
          break;
        case 'B':
          this.map.set(this.numberQuestion, 'B');
          this.buttonAnswerA = '#e7e7e7'
          this.buttonAnswerB = 'green';
          this.buttonAnswerC = '#e7e7e7';
          break;
        case 'C':
          this.map.set(this.numberQuestion, 'C');
          this.buttonAnswerA = '#e7e7e7';
          this.buttonAnswerB = '#e7e7e7';
          this.buttonAnswerC = 'green';
          break;
        default:
          this.allButtonSetColor();
          break;
      }
    }
  }
}

export class Categorie {
  constructor(public name: String, public categorie: String) {
    this.name = name;
    this.categorie = categorie;
  }
}

export class saveAnswer {
  constructor(public nrQuestion: Number, public answer: String, public goodAnswer: String) {
    this.nrQuestion = nrQuestion;
    this.answer = answer;
    this.goodAnswer = goodAnswer;
  }
}