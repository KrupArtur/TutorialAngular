export class Answer {
    constructor(public answer1: String, public answer2: String, public answer3: String) {
        this.answer1 = answer1;
        this.answer2 = answer2;
        this.answer3 = answer3;
       }    
}
