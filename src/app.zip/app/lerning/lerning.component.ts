import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Question } from "../test/model/question";

@Component({
  selector: 'app-lerning',
  templateUrl: './lerning.component.html',
  styleUrls: ['./lerning.component.css']
})
export class LerningComponent implements OnInit {
  buttonYes = 'white';
  buttonNo = 'white';
  buttonAnswer1 = 'white';
  buttonAnswer2 = 'white';
  buttonAnswer3 = 'white';

  questions: Array<Question>;
  _questionsInTest;
  private categorie = 'A';
  question: Question;
  numberQuestion: number = 0;

  _questions = new Array(
    new Question2('Test kategoria A', 'A'),
    new Question2('Test kategoria B', 'B'),
    new Question2('Test kategoria C', 'C')
  )

  constructor(private route: ActivatedRoute, private http: HttpClient) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this._questionsInTest = new Array();
      this.getQuestion(params.get("id"));
    })

    this.getAll().subscribe(data => {
      this.questions = data;
    });
  }

  getAll(): Observable<any> {
    return this.http.get('//localhost:9001/lerning/' + this.categorie);
  }

  getQuestion(categorie: String) {
    this._questions.forEach(_question => {
      _question.categorie == categorie ? this._questionsInTest.push(_question) : null
    });
  }

  public getQuestions() {
    try {       
      return this.base ? this.baseQuestions[this.numberQuestion] : this.questions[this.numberQuestion]; 
    } catch (error) { }
  }

  onKey(event: any) {
    this.numberQuestion = 1;
    this.numberQuestion = event.target.value - 1;
  }
  test(event: any){
    console.log(event.target.check());
  }

  getNumberQuestion() {
    return this.numberQuestion + 1;
  }

  nextQuestion() {
    this.numberQuestion++;
    this.buttonYes = 'white';
    this.buttonNo = 'white';
    this.buttonAnswer1 = 'white';
    this.buttonAnswer2 = 'white';
    this.buttonAnswer3 = 'white';
  }

  prevQuestion() {
    if (this.numberQuestion > 0) {
      this.numberQuestion -= 1;
      this.buttonYes = 'white';
      this.buttonNo = 'white';
      this.buttonAnswer1 = 'white';
      this.buttonAnswer2 = 'white';
      this.buttonAnswer3 = 'white';
    }
  }
  baseQuestions: Array<Question>
  base = false;

  log(event, type) {    
    this.baseQuestions = new Array;
    if(event.target.checked && type === 'base') {
      this.base = true;
        this.questions.forEach(question => {
          if (question.abbreviation === 'PODSTAWOWY')  
              this.baseQuestions.push(question);
    });
    } else if(event.target.checked && type === 'special'){  
      this.base = true;
      this.questions.forEach(question => {      
        if (question.abbreviation === 'SPECJALISTYCZNY')  
            this.baseQuestions.push(question);
    })} else {  
      this.base = false;
    }
  }

  checkIfAnswerIstEmpty() {
    try {
      if (this.getQuestions().answerPL.answer1 == '')
        return false;
      else
        return true;
    } catch (error) { }
  }
  
  answer() {
    switch (this.questions[this.numberQuestion].correctAnswer) {
      case 'T':
        this.buttonYes = 'green';
        this.buttonNo = 'red';
        break;
      case 'N':
        this.buttonYes = 'red';
        this.buttonNo = 'green';
        break;
      case 'A':
        this.buttonAnswer1 = 'green';
        this.buttonAnswer2 = 'red';
        this.buttonAnswer3 = 'red';
        break;
      case 'B':
        this.buttonAnswer1 = 'red';
        this.buttonAnswer2 = 'green';
        this.buttonAnswer3 = 'red';
        break;
      case 'C':
        this.buttonAnswer1 = 'red';
        this.buttonAnswer2 = 'red';
        this.buttonAnswer3 = 'green';
        break;
      default:
        this.buttonYes = 'white';
        this.buttonNo = 'white';
        this.buttonAnswer1 = 'white';
        this.buttonAnswer2 = 'white';
        this.buttonAnswer3 = 'white';
        break;
    }
  }
}

export class Question2 {
  constructor(public name: String, public categorie: String) {
    this.name = name;
    this.categorie = categorie;
  }
}
