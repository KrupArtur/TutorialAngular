import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lerning-test-work',
  templateUrl: './lerning-test-work.component.html',
  styleUrls: ['./lerning-test-work.component.css']
})
export class LerningTestWorkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
