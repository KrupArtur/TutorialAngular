import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  private categorie;
  _questions = new Array(
                          new Question('Test kategoria A','A'),
                          new Question('Test kategoria B','B'),
                          new Question('Test kategoria C','C')
                        )
  _questionsInTest;
  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this._questionsInTest = new Array();
      this.getQuestion(params.get("id")); 
    })    
  }

  getQuestion(categorie: String){
    this._questions.forEach( _question => { _question.categorie == categorie ? this._questionsInTest.push(_question) : null
    });
  }

}
export class Question{

  constructor(public img: String, public categorie: String){
    this.img = img;
    this.categorie = categorie;
  }

}

