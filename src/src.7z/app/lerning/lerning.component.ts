import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lerning',
  templateUrl: './lerning.component.html',
  styleUrls: ['./lerning.component.css']
})
export class LerningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
